//---DEFINIÇÔES---//
#define F_CPU 16000000UL

//---INCLUDES---//
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "funsape/globalDefines.hpp"
#include "funsape/device/hd44780.hpp"
#include "funsape/peripheral/timer0.hpp"
#include "funsape/peripheral/timer1.hpp"

Hd44780 lcd;
vuint8_t num = 0;
vuint8_t n0vf = 0;

void timer1OverflowCallback(void);
void stopwatchStart(void);
void stopwatchStop(void);
vuint32_t stopwatchGetTime(void);

//---MAIN---//
int main()
{
    // Variáveis
    Hd44780 lcd;
    uint16_t dia = 29;
    uint16_t mes = 4;
    uint16_t ano = 23;
    uint16_t hora = 11;
    uint16_t minuto = 20;
    uint16_t segundo = 00;

    // Disable USART (fix to solve bootloader issue)
    UCSR0A = 0;
    UCSR0B = 0;

    // Configurar os pinos do botão
    clrBit(DDRD, PD2);
    setBit(PORTD, PD2);                 // pin in pull-up
    clrMaskOffset(EICRA, 0b11, ISC00);  // trigger sense config at falling edge
    setMaskOffset(EICRA, 0b10, ISC00);  //
    setBit(EIMSK, INT0);                // Enable INT0 service routine

    // Configurar os pinos de controle do display
    lcd.controlPortSet(&DDRB, PB4, PB5);
    // Configurar os pinos de dados do display
    lcd.dataPortSet(&DDRB, PB0);
    lcd.init(Hd44780::Size::LCD_16X2, Hd44780::Font::FONT_5X8, true, false);
    lcd.stdio();

    //Timer1 configuration
    timer1.setMode(Timer1::Mode::NORMAL);
    timer1.setClockSource(Timer1::ClockSource::DISABLED);
    timer1.activateOverflowInterrupt();


    // Splash Screen
    printf(" %02d/%02d/20%02d %3s\n", dia, mes, ano, "SEG");
    printf("    %02d:%02d:%02d    \n", hora, minuto, segundo);
    delayMs(2000);
    lcd.clearScreen();

    sei();

    while(1) {
        vuint8_t n0vf = 0;
        stopwatchStart();
        delayMs(100);
        //lcd.clearScreen();
        //printf("Limpando...\n");
        //printf("Num%d\n", num++);
        stopwatchStop();
        lcd.clearScreen();
        printf("Time=%lu\n %u %u", stopwatchGetTime(), n0vf, TCNT1);
        delayMs(1000);
    }

    return 0;
}


void timer1OverflowCallback(void)
{
    n0vf++;
}

void stopwatchStart(void)
{
    // Clear all vars
    n0vf = 0;
    timer1.setCounterValue(0);
    // Timer1 run
    timer1.setClockSource(Timer1::ClockSource::PRESCALER_8);
}

void stopwatchStop(void)
{
    // Timer1 stop
    timer1.setClockSource(Timer1::ClockSource::DISABLED);
}

vuint32_t stopwatchGetTime(void)
{
    uint32_t totaltime = 0;

    totaltime = (uint32_t)n0vf * (0XFFFF + 1) + timer1.getCounterValue();

    return totaltime / 2;
}

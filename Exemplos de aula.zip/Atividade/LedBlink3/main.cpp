// ------------------------------------------------------------------------------
// Project:	External Interrupt
//File:		ledBlink.asm
//Author:	Fabio Schmitt Avelino
; Created:	2023 - 03 - 21
; Modified:	2023 - 03 - 21

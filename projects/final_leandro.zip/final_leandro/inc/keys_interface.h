/*
 * keys_interface.h
 *
 * Created: 4/11/2022 1:50:44 AM
 *  Author: mmyra
 */


// #ifndef KEYS_INTERFACE_H_
// #define KEYS_INTERFACE_H_

// #define keys_non		0
// #define keys_up			1
// #define keys_down		2
// #define keys_ok			3
// #define keys_cancel		4

// void keys_init();
// char keys_Feedback();


// #endif /* KEYS_INTERFACE_H_ */

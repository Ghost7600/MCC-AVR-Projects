#define F_CPU 16000000UL

#include "funsape/globalDefines.hpp"
#include "funsape/device/hd44780.hpp"
#include "funsape/peripheral/int1.hpp"


typedef union {
    struct  {
        vbool_t updateDisplay: 1;
        vbool_t readEncoder:   1;
        uint8_t unusedBits:   6;
    };
    uint8_t allFlags;
} systemFlags_t;


volatile systemFlags_t systemFlags;

int main()
{
    UCSR0A = 0;
    UCSR0B = 0;

    // Local variables
    Hd44780 lcd;
    uint16_t encoderCounter = 0;


    // Initialize variables
    systemFlags.allFlags = 0;

    //Configure LCD
    lcd.controlPortSet(&DDRB, PB4, PB5);
    lcd.dataPortSet(&DDRB, PB0);
    lcd.init(Hd44780::Size::LCD_16X2, Hd44780::Font::FONT_5X8, true, false);
    lcd.stdio();

    // LCD splash Screen
    printf("Encoder Example!\n");
    printf("   2023-05-19   \n");
    delayMs(2000);
    lcd.clearScreen();

    // Updates display info
    systemFlags.updateDisplay = true;

    //Configue encoder
    clrBit(DDRD, PD4);
    clrBit(DDRD, PD3);
    setBit(PORTD, PD4);
    setBit(PORTD, PD3);

    // Configure int1
    int1.init(Int1::SenseMode::FALLING_EDGE);
    int1.activateInterrupt();

    //Enable global interrupts
    sei();


    while(1) {

        //#######################################//
        //Process flags event machine - START    //
        //#######################################//

        //   >>>>>>>> UPDATE DISPLAY <<<<<<<<   //
        if(systemFlags.updateDisplay) {

            //Updates display info
            lcd.cursorMoveFirstLine();
            printf("counter = %d\n\n", encoderCounter);

            // Clear Flag
            systemFlags.updateDisplay = false;
        }

        //   >>>>>>>> READ ENCODER <<<<<<<<   //
        if(systemFlags.readEncoder) {
            //Reads the encoder
            if(isBitClr(PIND, PD4)) {
                encoderCounter++;
            } else {
                encoderCounter--;
            }

            systemFlags.updateDisplay = true;
            // Clear Flag
            systemFlags.readEncoder = false;
        }



    }

    return 0;
}
void int1InterruptCallback(void)
{
    systemFlags.readEncoder = true;
}

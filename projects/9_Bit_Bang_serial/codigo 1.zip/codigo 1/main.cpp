// Controller 1 - Keypad/Transmitter Code

//---DEFINIÇÔES---//
#define F_CPU 16000000UL

//---INCLUDES---//
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "funsape/globalDefines.hpp"
#include "funsape/peripheral/int0.hpp"
#include "funsape/peripheral/timer0.hpp"
#include "funsape/device/keypad.hpp"

//globals


//---MAIN---//
int main()
{
    //Config Keypad
    // Keypad keypad;
    // keypad.setPorts(&DDRC, PC0, &DDRB, PB0);
    // keypad.setKeyValues(Keypad::Type::KEYPAD_4X4,
    //         '7', '8', '9', 'A',
    //         '4', '5', '6', 'B',
    //         '1', '2', '3', 'C',
    //         'E', '0', 'F', 'D');
    // keypad.init(10);


    // Enabling interrupts
    sei();
    //Timer Configuration
    DDRD = 0xFF;
    setBit(PORTD,PD2);

    Timer0 timer0;
    timer0.setMode(Timer0::Mode::NORMAL);
    timer0.setClockSource(Timer0::ClockSource::PRESCALER_8);
    timer0.setCompareAValue(208);
    timer0.activateCompareAInterrupt();
    //timer0.activateOverflowInterrupt();
    while(1) {

    }

    return 0;
}

void timer1CompareACallback(void){
    // clrBit(PORTD, PD2);
    cplBit(PORTD, PD2);
    timer0.setCounterValue(0);
}
void timer1OverflowCallback(void){
    cplBit(PORTD, PD2);
    timer0.setCounterValue(0);
    // clrBit(PORTD, PD2);
}

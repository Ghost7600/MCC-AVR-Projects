//---Definições---//
#define F_CPU 16000000UL

//---Includes---//
#include "funsape/globalDefines.hpp"
#include "funsape/peripheral/int0.hpp"
#include "funsape/peripheral/timer1.hpp"
#include "funsape/device/hd44780.hpp"

//---Definições LED---//
#define LED_DIR     DDRC
#define LED_OUT     PORTC
#define LED_BIT     PC0

//---Definições PINOS de dados LCD---//
#define LCD_DATA_DIR        DDRB
#define LCD_DATA_OUT        PORTB
#define LCD_DATA_FIRST      PB0

//---Definições PINOS de controle LCD---//
#define LCD_CONTROL_DIR     DDRB
#define LCD_CONTROL_OUT     PORTB
#define LCD_CONTROL_E       PB4
#define LCD_CONTROL_RS      PB5

typedef union {
    struct {
        bool_t updateDisplay        : 1;
        bool_t readRtc              : 1;
        uint8_t unusedBits          : 6;
    };
    uint8_t allFlags;

} systemFlags_t;

//Global variables
volatile systemFlags_t systemFlags;
volatile uint8_t counter = 0;


int main()
{
    //Local variables
    Hd44780 lcd;

    //Configure LED for test
    setBit(LED_DIR, LED_BIT);
    clrBit(LED_OUT, LED_BIT);

    //Configure LCD
    lcd.controlPortSet(&LCD_CONTROL_DIR, LCD_CONTROL_E, LCD_CONTROL_RS);
    lcd.dataPortSet(&LCD_DATA_DIR, LCD_DATA_FIRST);
    lcd.init(Hd44780::Size::LCD_16X2, Hd44780::Font::FONT_5X8, true, false);
    lcd.displayStateSet(Hd44780::DisplayState::CURSOR_OFF);
    lcd.stdio();

    //Show splash screen
    printf(" Clock Example! \n");
    printf(" V1.0 build 238 \n");
    delayMs(2000);
    lcd.clearScreen();
    systemFlags.updateDisplay = true;

    //Configure INT0
    int0.init(Int0::SenseMode::FALLING_EDGE);
    int0.activateInterrupt();

    //Enable global interrupts
    sei();

    while(1) {

        //Event machine core
        if(systemFlags.updateDisplay) {
            //update display
            printf("%d\n\n", counter);
            systemFlags.updateDisplay = false;
        }
        if(systemFlags.readRtc) {

            //Reads RTC
            counter++;
            systemFlags.updateDisplay = true;
            //Clear flag
            systemFlags.readRtc = false;
        }

        return 0;
    }
    cplBit(LED_OUT, LED_BIT);
    delayMs(250);
}


void int0InterruptCallback()
{
    systemFlags.readRtc = true;
}

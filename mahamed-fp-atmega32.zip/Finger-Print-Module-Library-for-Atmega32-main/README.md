# Finger-Print-Module-Library-for-Atmega32
Library for R305 R307 FingerPrint Module that is controlled using AVR atmega32

<img src="download.jpg" alt="T_T">
<img src="original.jpeg" alt="T_T">
